package tech.devinhouse.ilog.m01s06ex1e2.models;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Pet {
    private Integer id;
    private String nome;
    private String raca;
    private Integer idade;
    private String alimentoPreferido;

    public static Integer contador = 0;

    public Pet() {
        this.id = generateId();
    }

    public Pet(Integer id, String nome, String raca, Integer idade, String alimentoPreferido) {
        this.id = generateId();
        this.nome = nome;
        this.raca = raca;
        this.idade = idade;
        this.alimentoPreferido = alimentoPreferido;
    }

    private Integer generateId() {
        return ++contador;
    }
}
