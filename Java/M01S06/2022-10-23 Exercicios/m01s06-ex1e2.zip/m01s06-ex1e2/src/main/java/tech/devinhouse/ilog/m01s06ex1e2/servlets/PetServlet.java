package tech.devinhouse.ilog.m01s06ex1e2.servlets;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import tech.devinhouse.ilog.m01s06ex1e2.models.Pet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(value = "/pet")
public class PetServlet extends HttpServlet {
    private List<Pet> pets = new ArrayList<>();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if(pets.isEmpty()) {
            resp.getWriter().println("Nao ha nenhum pet cadastrado no momento.");
        } else {
            for(Pet pet : pets) resp.getWriter().println(pet);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String nome = req.getParameter("nome");
        Integer idade = Integer.parseInt(req.getParameter("idade"));
        String raca = req.getParameter("raca");
        String alimentoPreferido = req.getParameter("alimentoPreferido");
        Pet pet = Pet.builder()
                .nome(nome)
                .idade(idade)
                .raca(raca)
                .alimentoPreferido(alimentoPreferido)
                .build();
        pets.add(pet);
        resp.getWriter().println(pet);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            Integer id = Integer.parseInt(req.getParameter("id"));
            Pet pet = findPetById(id);

            if(pet == null) resp.getWriter().println(false);
            else {
                String nome = req.getParameter("nome");
                Integer idade = Integer.parseInt(req.getParameter("idade"));
                String raca = req.getParameter("raca");
                String alimentoPreferido = req.getParameter("alimentoPreferido");

                pet.setNome(nome);
                pet.setIdade(idade);
                pet.setRaca(raca);
                pet.setAlimentoPreferido(alimentoPreferido);

                resp.getWriter().println(pet);
            }
        } catch (Exception e) {
            resp.getWriter().println(e + e.getMessage());
        }
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try{
            Integer id = Integer.parseInt(req.getParameter("id"));
            Pet pet = findPetById(id);

            if(pet == null) resp.getWriter().println(false);
            else {
                pets.remove(pet);
                resp.getWriter().println(true);
            }
        } catch (Exception e) {
            resp.getWriter().println(e + e.getMessage());
        }
    }

    private Pet findPetById(Integer id) {
        for (Pet pet: pets) if(id.equals(pet.getId())) return pet;
        return null;
    }
}
