package tech.devinhouse.m01s06ex36.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import tech.devinhouse.m01s06ex36.models.Pet;
import tech.devinhouse.m01s06ex36.services.PetService;

import java.util.List;

@RestController
@RequestMapping(value = "pet")
public class PetController {
    @Autowired
    private PetService petService;

    @GetMapping
    public List<Pet> get() {
        return petService.findAll();
    }

    @GetMapping(path = "{id}")
    public Pet get(@PathVariable Integer id) {
        return petService.findById(id);
    }

    @PostMapping
    public Pet post(@RequestBody Pet pet) {
        return petService.save(pet);
    }

    @PutMapping(path = "{id}")
    public Pet put(@PathVariable Integer id, @RequestBody Pet pet) {
        pet.setId(id);
        return petService.save(pet);
    }

    @DeleteMapping
    public void delete(Integer id) {
        petService.delete(id);
    }
}
