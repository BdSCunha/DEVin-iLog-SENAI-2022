package tech.devinhouse.m01s06ex36.repositories;

import org.springframework.stereotype.Repository;
import tech.devinhouse.m01s06ex36.models.Tutor;

import java.util.ArrayList;
import java.util.List;

@Repository
public class TutorRepository {
    public static Integer contador = 0;
    private Integer generateId() {
        return ++contador;
    }

    public static List<Tutor> tutores = new ArrayList<>();

    public List<Tutor> findAll() {
        return tutores;
    }

    public Tutor findById(Integer id) {
        for (Tutor tutor: tutores) if(id == tutor.getId()) return tutor;
        return null;
    }

    public Tutor save(Tutor tutor) {
        if(findById(tutor.getId()) == null) {
            tutor.setId(generateId());
            tutores.add(tutor);
        }
        else {
            Tutor tutor2BEdited = findById(tutor.getId());
            tutor2BEdited.setNome(tutor.getNome());
        }
        return tutor;
    }

    public boolean delete(Integer id) {
        Tutor tutor = findById(id);

        if(tutor == null) return false;

        tutores.remove(tutor);
        return true;
    }
}
