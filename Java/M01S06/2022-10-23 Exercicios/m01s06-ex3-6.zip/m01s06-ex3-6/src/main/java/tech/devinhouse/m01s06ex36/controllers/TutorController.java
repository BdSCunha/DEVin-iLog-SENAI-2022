package tech.devinhouse.m01s06ex36.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import tech.devinhouse.m01s06ex36.models.Tutor;
import tech.devinhouse.m01s06ex36.services.TutorService;

import java.util.List;

@RestController
@RequestMapping(value = "tutor")
public class TutorController {
    @Autowired
    private TutorService tutorService;

    @GetMapping
    public List<Tutor> get() {
        return tutorService.findAll();
    }

    @GetMapping(path = "{id}")
    public Tutor get(@PathVariable Integer id) {
        return tutorService.findById(id);
    }

    @PostMapping
    public Tutor post(@RequestBody Tutor tutor) {
        return tutorService.save(tutor);
    }

    @PutMapping(path = "{id}")
    public Tutor put(@PathVariable Integer id, @RequestBody Tutor tutor) {
        tutor.setId(id);
        return tutorService.save(tutor);
    }

    @DeleteMapping
    public void delete(Integer id) {
        tutorService.delete(id);
    }
}
