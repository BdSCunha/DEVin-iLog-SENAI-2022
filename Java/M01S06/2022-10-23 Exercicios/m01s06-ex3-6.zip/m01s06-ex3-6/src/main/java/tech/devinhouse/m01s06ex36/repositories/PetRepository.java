package tech.devinhouse.m01s06ex36.repositories;

import org.springframework.stereotype.Repository;
import tech.devinhouse.m01s06ex36.models.Pet;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PetRepository {
    public static Integer contador = 0;
    private Integer generateId() {
        return ++contador;
    }

    public static List<Pet> pets = new ArrayList<>();

    public List<Pet> findAll() {
        return pets;
    }

    public Pet findById(Integer id) {
        for (Pet pet: pets) if(id == pet.getId()) return pet;
        return null;
    }

    public Pet save(Pet pet) {
        if(findById(pet.getId()) == null) {
            pet.setId(generateId());
            pets.add(pet);
        }
        else {
            Pet pet2BEdited = findById(pet.getId());
            pet2BEdited.setNome(pet.getNome());
            pet2BEdited.setRaca(pet.getRaca());
            pet2BEdited.setAlimentoPreferido(pet.getAlimentoPreferido());
        }
        return pet;
    }

    public boolean delete(Integer id) {
        Pet pet = findById(id);

        if(pet == null) return false;

        pets.remove(pet);
        return true;
    }
}
