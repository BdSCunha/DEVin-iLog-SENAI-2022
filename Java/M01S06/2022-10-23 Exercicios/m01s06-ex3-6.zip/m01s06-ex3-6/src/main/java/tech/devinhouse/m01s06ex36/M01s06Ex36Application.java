package tech.devinhouse.m01s06ex36;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M01s06Ex36Application {

	public static void main(String[] args) {
		SpringApplication.run(M01s06Ex36Application.class, args);
	}
}
