package tech.devinhouse.m01s06ex36;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M01s06Ex36ApplicationTests {

	@Test
	void contextLoads() {
	}

}
